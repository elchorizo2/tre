/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lfauq <lfauq@student.42nice.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/28 13:48:24 by lfauq             #+#    #+#             */
/*   Updated: 2024/09/29 14:25:26 by lfauq            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


int ft_error()
{}



bool	is_positive_number(char *str)
{
	int	i;

	if (!str || *str == '\0' || *str == '-' || *str == '+')
		return (false);
	i = 0;
	while (str[i])
	{
		if (is_num(str[i]))
			return (false);
		i++;
	}
	return (true);
}

int	main(int argc, char **argv)
{
	if (argc == 2)
	{
		if (!is_positive_number(argv[1]))
			ft_putstr("Dict Error\n");
		else
			convert_number(argv[1]);
	}
	else if (argc == 3)
	{
		if (!is_positive_number(argv[2]))
			ft_putstr("Dict Error\n");
		else if (!parse_dict(argv[1]))
		ft_putstr("Dict Error\n");
		else
			convert_number_with_dict(argv[2]);
	}
	else
		ft_putstr("Dict Error\n");
	return (0);
}
