/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush02 (1).c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lfauq <lfauq@student.42nice.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/28 13:23:52 by kpaita            #+#    #+#             */
/*   Updated: 2024/09/29 14:25:25 by lfauq            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include "rush.h"


/*#define BUF_SIZE 1024
#define WORD_LENGTH 100
#define MAX_LINES 100

typedef	struct
{
	int	number;
	char	word[WORD_LENGTH]
} Dictline;


int	line_count = 0;
*/


void	ft_putchar(char *str);

void	ft_linelogic(char *line, int length, Dictline	*dictionary)
{
	char	*colon;
	char	*word;
	char	*end;
	int		number;

	colon = ft_strchr(line, ':'); //ft a faire
	if (colon == NULL)
		return (-1); //gestion d'erreur
	*colon = '\0';
	number = ft_atoi(line);
	word = colon + 1;
	while (*word == ' ')
		word++;
	end = word + ft_strlen(word) - 1;
	while (end > word && (*end == ' ' || *end == '\n'))
		end--;
	*(end + 1) = '\0';
	if (line_count >= MAX_LINES)
		return -1;
	dictionary[line_count].number = number;
	ft_strncpy(dictionary[line_count].word, word, WORD_LENGTH - 1);
	dictionary[line_count].word[WORD_LENGTH - 1] = '\0';
	line_count++;
}

void	ft_read_line(void)
{
	int	i;
	int	line_start;
	line_start = 0;
	char	buf[BUF_SIZE];
	ssize_t	numRead;

	buf[numRead] = '\0';
	i = 0;
	while (i < numRead)
	{
		if (buf[i] == '\n')
		{
			ft_linelogic(&buf[line_start], i - line_start);
			line_start = i + 1;
		}
		i++;
	}
	if (line_start < numRead)
		ft_linelogic(&buf[line_start], numRead - line_start);
	line_start = 0;
	numRead = read(fd, buf, BUF_SIZE - 1);
}

int	ft_read_file(void)
{
	int	fd;
	char	buf[BUF_SIZE];
	ssize_t	numRead;

	fd = open("numbers.dict", O_RDONLY);
	if (fd != -1)
	{
		numRead = read(fd, buf, BUF_SIZE - 1);
		while (numRead > 0)
			ft_read_line();
	}
	else
	{
		write(1, "Dict Error\n", 11);
		return (-1);
	}
}
