/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kpaita <kpaita@student.42nice.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/29 13:25:39 by kpaita            #+#    #+#             */
/*   Updated: 2024/09/29 13:29:24 by kpaita           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH_H
#define RUSH_H

char *ft_strchr(const char *s, int c);
int	ft_strlen(char *str);
char	*ft_strncpy(char *dest, char *src, unsigned int n);
int	ft_atoi(char *str);

#endif