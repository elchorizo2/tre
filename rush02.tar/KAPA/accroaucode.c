/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   accroaucode.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lfauq <lfauq@student.42nice.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/28 13:23:52 by kpaita            #+#    #+#             */
/*   Updated: 2024/09/29 14:25:32 by lfauq            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <addfcn.h>

#define BUF_SIZE 1024
#define WORD_LENGTH 100
#define MAX_LINES 100

typedef	struct
{
	int	number;
	char	word[WORD_LENGTH]
} Dictline;

Dictline	dictionary[MAX_LINES];
int	dict_size = 0;

void	ft_linelogic(char *line, int length)
{
	char	*semicolon;
	char	*word;
	char	*end;
	int		number;
	semicolon = ft_strchr(line, ':');
	if (semicolon == NULL)
	{
		return ;
	}
	*semicolon = '\0';
	number = ft_atoi(line);
	word = semicolon + 1;
	while (*word == ' ')
	{
		word++;
	}
	end = word + strlen(word) - 1;
	while (end > word && (*end == ' ' || *end == '\n'))
	{
		end--;
	}
	*(end + 1) = '\0';
	dictionary[dict_size].number = number;
	ft_strncpy(dictionary[dict_size].word, word, WORD_LENGTH - 1);
	dictionary[dict_size].word[WORD_LENGTH - 1] = '\0';
	dict_size++;
}

int ft_read_file(void)
{
	int	fd;
	int	i;
	int	line_start;
	char	buf[BUF_SIZE];
	ssize_t	numRead;ft_putchar.c

	line_start = 0;
	fd = open("numbers.dict", O_RDONLY);
	if (fd != -1)
	{
		numRead = read(fd, buf, BUF_SIZE - 1);
		while (numRead > 0)
		{
			buf[numRead] = '\0';
			i = 0;
			while (i < numRead)
			{
				if (buf[i] == '\n')
				{
					ft_linelogic(&buf[line_start], i - line_start);
					line_start = i + 1;
				}
				i++;
			}
			if (line_start < numRead)
			{
				ft_linelogic(&buf[line_start], numRead - line_start);
			}
			line_start = 0;
			numRead = read(fd, buf, BUF_SIZE - 1);
		}
		close(fd);
		return (0);
	}
	else
	{
		write(1, "Dict Error\n", 11);
		return (-1);
	}
}

void ft_translatenbr(int number, char *res)
{
	int	i;

	i = 0;
	while (i < dict_size)
	{
		if (dictionary[i].number == number)
		{
			ft_strncpy(res, dictionary[i].word, WORD_LENGTH);
			return;
		}
		i++;
	}
}

int	main(void)
{
	ft_read_file();
	return (0);
}
