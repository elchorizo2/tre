#ifndef RUSH_H
#define RUSH_H

#define BUF_SIZE 1024
#define WORD_LENGTH 100
#define MAX_LINES 100
xz
#include <stdbool.h>
#include <unistd.h>


void	convert_number(char *number);
void	convert_number_with_dict(char *number);
int		parse_dict(char *dict);
int		white_space(const char *str);
int		ft_atoi(char *str);
int		ft_strchr();
int		ft_strlen();
int		ft_strncpy();
int		ft_putstr(char *str);
int		ft_is_positive_number(char *str);
int		ft_read_file(void);
void	ft_linelogic(char *line, int length); //aaa
int		ft_read_file(void);
bool	is_num(const char c);


typedef	struct
{
	int	number;
	char	word[WORD_LENGTH]
} Dictline;

#endif
