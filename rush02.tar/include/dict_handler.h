#ifndef DICT_HANDLER_H
# define DICT_HANDLER_H

void	convert_number(char *number);
int		parse_dict(char *dict);
void	convert_number_with_dict(char *number);

#endif
